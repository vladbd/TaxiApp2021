﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atestat_Taxi
{
    public partial class Adaugare : Form
    {
        public Adaugare()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdaugaClient frm = new AdaugaClient();
            frm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdaugareSofer frm = new AdaugareSofer();
            frm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdaugareMasina frm = new AdaugareMasina();
            frm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AdaugareCursa frm = new AdaugareCursa();
            frm.Show();
        }
    }
}
