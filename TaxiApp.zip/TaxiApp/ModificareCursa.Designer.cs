﻿
namespace Atestat_Taxi
{
    partial class ModificareCursa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label Id_masina_Label;
            System.Windows.Forms.Label durataLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModificareCursa));
            this.CursadataGridView = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Id_masina = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Id_sofer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Id_client = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.durataDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.momentplecareDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.momentsosireDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pretDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lungimetraseuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cursaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taxiDataSet = new Atestat_Taxi.TaxiDataSet();
            this.cursaTableAdapter = new Atestat_Taxi.TaxiDataSetTableAdapters.CursaTableAdapter();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.masinaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.soferBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.durataTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.masinaTableAdapter = new Atestat_Taxi.TaxiDataSetTableAdapters.MasinaTableAdapter();
            this.soferTableAdapter = new Atestat_Taxi.TaxiDataSetTableAdapters.SoferTableAdapter();
            this.clientTableAdapter = new Atestat_Taxi.TaxiDataSetTableAdapters.ClientTableAdapter();
            label6 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            Id_masina_Label = new System.Windows.Forms.Label();
            durataLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.CursadataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cursaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masinaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soferBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(216, 244);
            label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(85, 13);
            label6.TabIndex = 91;
            label6.Text = "Lungime_traseu:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(216, 220);
            label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(29, 13);
            label5.TabIndex = 90;
            label5.Text = "Pret:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(216, 164);
            label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(86, 13);
            label4.TabIndex = 89;
            label4.Text = "Moment_plecare";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(11, 191);
            label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(32, 13);
            label3.TabIndex = 88;
            label3.Text = "Sofer";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(11, 219);
            label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(33, 13);
            label2.TabIndex = 87;
            label2.Text = "Client";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(216, 191);
            label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(78, 13);
            label1.TabIndex = 86;
            label1.Text = "Moment_sosire";
            // 
            // Id_masina_Label
            // 
            Id_masina_Label.AutoSize = true;
            Id_masina_Label.Location = new System.Drawing.Point(11, 167);
            Id_masina_Label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            Id_masina_Label.Name = "Id_masina_Label";
            Id_masina_Label.Size = new System.Drawing.Size(41, 13);
            Id_masina_Label.TabIndex = 83;
            Id_masina_Label.Text = "Masina";
            // 
            // durataLabel
            // 
            durataLabel.AutoSize = true;
            durataLabel.Location = new System.Drawing.Point(14, 248);
            durataLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            durataLabel.Name = "durataLabel";
            durataLabel.Size = new System.Drawing.Size(42, 13);
            durataLabel.TabIndex = 84;
            durataLabel.Text = "Durata:";
            // 
            // CursadataGridView
            // 
            this.CursadataGridView.AutoGenerateColumns = false;
            this.CursadataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CursadataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.Id_masina,
            this.Id_sofer,
            this.Id_client,
            this.durataDataGridViewTextBoxColumn,
            this.momentplecareDataGridViewTextBoxColumn,
            this.momentsosireDataGridViewTextBoxColumn,
            this.pretDataGridViewTextBoxColumn,
            this.lungimetraseuDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.CursadataGridView.DataSource = this.cursaBindingSource;
            this.CursadataGridView.Location = new System.Drawing.Point(2, 0);
            this.CursadataGridView.Name = "CursadataGridView";
            this.CursadataGridView.Size = new System.Drawing.Size(646, 153);
            this.CursadataGridView.TabIndex = 0;
            // 
            // id
            // 
            this.id.DataPropertyName = "Id";
            this.id.HeaderText = "Id";
            this.id.Name = "id";
            this.id.Visible = false;
            // 
            // Id_masina
            // 
            this.Id_masina.DataPropertyName = "Id_masina";
            this.Id_masina.HeaderText = "Id_masina";
            this.Id_masina.Name = "Id_masina";
            this.Id_masina.Visible = false;
            // 
            // Id_sofer
            // 
            this.Id_sofer.DataPropertyName = "Id_sofer";
            this.Id_sofer.HeaderText = "Id_sofer";
            this.Id_sofer.Name = "Id_sofer";
            this.Id_sofer.Visible = false;
            // 
            // Id_client
            // 
            this.Id_client.DataPropertyName = "Id_client";
            this.Id_client.HeaderText = "Id_client";
            this.Id_client.Name = "Id_client";
            this.Id_client.Visible = false;
            // 
            // durataDataGridViewTextBoxColumn
            // 
            this.durataDataGridViewTextBoxColumn.DataPropertyName = "Durata";
            this.durataDataGridViewTextBoxColumn.HeaderText = "Durata";
            this.durataDataGridViewTextBoxColumn.Name = "durataDataGridViewTextBoxColumn";
            // 
            // momentplecareDataGridViewTextBoxColumn
            // 
            this.momentplecareDataGridViewTextBoxColumn.DataPropertyName = "Moment_plecare";
            this.momentplecareDataGridViewTextBoxColumn.HeaderText = "Moment_plecare";
            this.momentplecareDataGridViewTextBoxColumn.Name = "momentplecareDataGridViewTextBoxColumn";
            // 
            // momentsosireDataGridViewTextBoxColumn
            // 
            this.momentsosireDataGridViewTextBoxColumn.DataPropertyName = "Moment_sosire";
            this.momentsosireDataGridViewTextBoxColumn.HeaderText = "Moment_sosire";
            this.momentsosireDataGridViewTextBoxColumn.Name = "momentsosireDataGridViewTextBoxColumn";
            // 
            // pretDataGridViewTextBoxColumn
            // 
            this.pretDataGridViewTextBoxColumn.DataPropertyName = "Pret";
            this.pretDataGridViewTextBoxColumn.HeaderText = "Pret";
            this.pretDataGridViewTextBoxColumn.Name = "pretDataGridViewTextBoxColumn";
            // 
            // lungimetraseuDataGridViewTextBoxColumn
            // 
            this.lungimetraseuDataGridViewTextBoxColumn.DataPropertyName = "Lungime_traseu";
            this.lungimetraseuDataGridViewTextBoxColumn.HeaderText = "Lungime_traseu";
            this.lungimetraseuDataGridViewTextBoxColumn.Name = "lungimetraseuDataGridViewTextBoxColumn";
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            // 
            // cursaBindingSource
            // 
            this.cursaBindingSource.DataMember = "Cursa";
            this.cursaBindingSource.DataSource = this.taxiDataSet;
            // 
            // taxiDataSet
            // 
            this.taxiDataSet.DataSetName = "TaxiDataSet";
            this.taxiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cursaTableAdapter
            // 
            this.cursaTableAdapter.ClearBeforeFill = true;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(315, 188);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 99;
            this.dateTimePicker2.Value = new System.DateTime(2021, 5, 27, 0, 0, 0, 0);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(315, 159);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 98;
            this.dateTimePicker1.Value = new System.DateTime(2021, 5, 27, 0, 0, 0, 0);
            // 
            // comboBox4
            // 
            this.comboBox4.DataSource = this.masinaBindingSource;
            this.comboBox4.DisplayMember = "Denumire";
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(57, 167);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 97;
            this.comboBox4.ValueMember = "Denumire";
            // 
            // masinaBindingSource
            // 
            this.masinaBindingSource.DataMember = "Masina";
            this.masinaBindingSource.DataSource = this.taxiDataSet;
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.soferBindingSource;
            this.comboBox3.DisplayMember = "Nume";
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(57, 191);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 96;
            this.comboBox3.ValueMember = "Nume";
            // 
            // soferBindingSource
            // 
            this.soferBindingSource.DataMember = "Sofer";
            this.soferBindingSource.DataSource = this.taxiDataSet;
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.clientBindingSource;
            this.comboBox2.DisplayMember = "Nume";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(57, 218);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 95;
            this.comboBox2.ValueMember = "Nume";
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.taxiDataSet;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(315, 248);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(71, 20);
            this.textBox5.TabIndex = 93;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(315, 220);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(71, 20);
            this.textBox1.TabIndex = 92;
            // 
            // durataTextBox
            // 
            this.durataTextBox.Location = new System.Drawing.Point(57, 248);
            this.durataTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.durataTextBox.Name = "durataTextBox";
            this.durataTextBox.Size = new System.Drawing.Size(55, 20);
            this.durataTextBox.TabIndex = 85;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(409, 240);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(171, 28);
            this.button1.TabIndex = 100;
            this.button1.Text = "Modifica inregistrarea selectata";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // masinaTableAdapter
            // 
            this.masinaTableAdapter.ClearBeforeFill = true;
            // 
            // soferTableAdapter
            // 
            this.soferTableAdapter.ClearBeforeFill = true;
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // ModificareCursa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(646, 288);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(label6);
            this.Controls.Add(label5);
            this.Controls.Add(label4);
            this.Controls.Add(label3);
            this.Controls.Add(label2);
            this.Controls.Add(label1);
            this.Controls.Add(Id_masina_Label);
            this.Controls.Add(durataLabel);
            this.Controls.Add(this.durataTextBox);
            this.Controls.Add(this.CursadataGridView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ModificareCursa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ModificareCursa";
            this.Load += new System.EventHandler(this.ModificareCursa_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CursadataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cursaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masinaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soferBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView CursadataGridView;
        private TaxiDataSet taxiDataSet;
        private System.Windows.Forms.BindingSource cursaBindingSource;
        private TaxiDataSetTableAdapters.CursaTableAdapter cursaTableAdapter;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox durataTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_masina;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_sofer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_client;
        private System.Windows.Forms.DataGridViewTextBoxColumn durataDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn momentplecareDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn momentsosireDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pretDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lungimetraseuDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource masinaBindingSource;
        private TaxiDataSetTableAdapters.MasinaTableAdapter masinaTableAdapter;
        private System.Windows.Forms.BindingSource soferBindingSource;
        private TaxiDataSetTableAdapters.SoferTableAdapter soferTableAdapter;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private TaxiDataSetTableAdapters.ClientTableAdapter clientTableAdapter;
    }
}