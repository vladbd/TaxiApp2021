﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Atestat_Taxi
{
    public partial class AdaugareCursa : Form
    {
        SqlConnection conn;
        public AdaugareCursa()
        {
            InitializeComponent();
        }
        private void ConfirmRegister_Click(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(((DataRowView)comboBox4.SelectedValue)["Id"]);
            int j = Convert.ToInt32(((DataRowView)comboBox3.SelectedValue)["Id"]);
            int k = Convert.ToInt32(((DataRowView)comboBox2.SelectedValue)["Id"]);
            String insertSql = "INSERT INTO Cursa (Id_masina, Id_sofer,Id_client ,Durata, Moment_plecare, Moment_sosire,Pret, Lungime_traseu ,status) VALUES (";
            insertSql += i + ", " + j + ", " + k + ", " + Convert.ToInt32(durataTextBox.Text) + ", '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "', '" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "', " + Convert.ToInt32(textBox1.Text) + ", " + Convert.ToInt32(textBox5.Text) + " , 1)";
            //insertSql += i + ", " + j + ", " + k + ", " + Convert.ToInt32(durataTextBox.Text) + ", '" + dateTimePicker1.Value + "', '" + dateTimePicker2.Value + "', " + Convert.ToInt32(textBox1.Text) + ", " + Convert.ToInt32(textBox5.Text) + " , 1)";
            //MessageBox.Show(insertSql);
            if (conn == null)
                conn = new SqlConnection(Properties.Settings.Default.dbConn);
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            SqlCommand cmd = new SqlCommand(insertSql, conn);
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
                MessageBox.Show("Adaugare cu succes !", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Eroare la adaugarea in tabela !", "Atentie !", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void AdaugareCursa_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'taxiDataSet3.Client' table. You can move, or remove it, as needed.
            this.clientTableAdapter.Fill(this.taxiDataSet3.Client);
            // TODO: This line of code loads data into the 'taxiDataSet2.Sofer' table. You can move, or remove it, as needed.
            this.soferTableAdapter.Fill(this.taxiDataSet2.Sofer);
            // TODO: This line of code loads data into the 'taxiDataSet1.Cursa' table. You can move, or remove it, as needed.
            this.cursaTableAdapter.Fill(this.taxiDataSet1.Cursa);
            // TODO: This line of code loads data into the 'taxiDataSet.Masina' table. You can move, or remove it, as needed.
            this.masinaTableAdapter.Fill(this.taxiDataSet.Masina);

        }
    }
    }

