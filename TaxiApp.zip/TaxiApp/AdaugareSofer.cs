﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Atestat_Taxi
{
    public partial class AdaugareSofer : Form
    {
        SqlConnection conn;
        public AdaugareSofer()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String insertSql = "INSERT INTO Sofer (Nume, Prenume, Cnp, Localitate, Adresa, Telefon, Email, Data_angajarii, Numar_autorizatie, Status) VALUES ('";
            insertSql += inputNume.Text + "', '" + inputPrenume.Text + "', '" + inputcnp.Text + "', '" + inputLoc.Text + "', '" + InputAdresa.Text + "', '" + ImputTelefon.Text + "', '" + ImputEmail.Text;
            insertSql += "', '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "', '" + ImputNraut.Text + "' , 1)";

            //MessageBox.Show(insertSql);

            if (conn == null)
                conn = new SqlConnection(Properties.Settings.Default.dbConn);
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            SqlCommand cmd = new SqlCommand(insertSql, conn);
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
                MessageBox.Show("Adaugare cu succes !", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Eroare la adaugarea in tabela !", "Atentie !", MessageBoxButtons.OK, MessageBoxIcon.Error);
           
        }
    }
    }

