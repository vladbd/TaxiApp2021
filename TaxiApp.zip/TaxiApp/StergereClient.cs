﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Atestat_Taxi
{
    public partial class StergereClient : Form
    {
        SqlConnection connection;
        public StergereClient()
        {
            InitializeComponent();
        }

        private void StergereClient_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'taxiDataSet.Client' table. You can move, or remove it, as needed.
            this.clientTableAdapter.Fill(this.taxiDataSet.Client);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult response = MessageBox.Show("Sunteti sigur ?", "Atentie !", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (response == DialogResult.Yes)
            {
                int id = Convert.ToInt32(ClientdataGridView.CurrentRow.Cells["Id"].Value);
                String updateQuery = "UPDATE Client SET [status] = 2 ";
                updateQuery += "WHERE id = @id";
                if (connection == null)
                    connection = new SqlConnection(Properties.Settings.Default.dbConn);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                SqlCommand cmd = new SqlCommand(updateQuery, connection);
                cmd.Parameters.AddWithValue("@id", id);
                int result = cmd.ExecuteNonQuery();
                if (result == 1)
                {
                    MessageBox.Show("Stergerea s-a realizat cu succes !", "Success !", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clientTableAdapter.Fill(taxiDataSet.Client);
                }
                else
                    MessageBox.Show("Eroare la stergerea datelor !", "Eroare !", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
