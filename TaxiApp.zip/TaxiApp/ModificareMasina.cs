﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Atestat_Taxi
{
    public partial class ModificareMasina : Form
    {
        SqlConnection connection;
        public ModificareMasina()
        {
            InitializeComponent();
        }

        private void ModificareMasina_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'taxiDataSet.Masina' table. You can move, or remove it, as needed.
            this.masinaTableAdapter.Fill(this.taxiDataSet.Masina);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Sunteti sigur ca vreti sa salvati modificarile ?", "Atentie !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (r == DialogResult.Yes)
            {
                String updateQuery = "UPDATE Masina SET ";
                updateQuery += "[Id_tip_masina ] = @Id_tip_masina_, [Indicativ] = @Indicativ, [Denumire] = @Denumire, [Nr_inmatriculare] = @Nr_inmatriculare, [Data_inregistrarii] = @Data_inregistrarii, [Id_tip_combustibil] = @Id_tip_combustibil, [Status] = @Status ";
                updateQuery += "WHERE id = @id";

                int id = Convert.ToInt32(MasinadataGridView.CurrentRow.Cells["Id"].Value);
                //MessageBox.Show(updateQuery);
                if (connection == null)
                    connection = new SqlConnection(Properties.Settings.Default.dbConn);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                SqlCommand cmd = new SqlCommand(updateQuery, connection);
                cmd.Parameters.AddWithValue("@Id_tip_masina_", inputNume.Text);
                cmd.Parameters.AddWithValue("@Indicativ", inputInd.Text);
                cmd.Parameters.AddWithValue("@Denumire", InputDen.Text);
                cmd.Parameters.AddWithValue("@Nr_inmatriculare", inputNrinm.Text);
                cmd.Parameters.AddWithValue("@Data_inregistrarii", dateTimePicker1.Value.ToString("MM/dd/yyyy"));
                cmd.Parameters.AddWithValue("@Id_tip_combustibil", numericUpDown.Value);
                cmd.Parameters.AddWithValue("@Status", 1);
                cmd.Parameters.AddWithValue("@id", id);

                int result = cmd.ExecuteNonQuery();
                if (result == 1)
                {
                    MessageBox.Show("Modificarea s-a realizat cu succes !", "Success !", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    masinaTableAdapter.Fill(taxiDataSet.Masina);
                }
                else
                    MessageBox.Show("Eroare la modificarea datelor !", "Eroare !", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
