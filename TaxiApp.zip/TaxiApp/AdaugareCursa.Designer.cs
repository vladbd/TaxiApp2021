﻿
namespace Atestat_Taxi
{
    partial class AdaugareCursa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label Id_masina_Label;
            System.Windows.Forms.Label durataLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdaugareCursa));
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.masinaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taxiDataSet = new Atestat_Taxi.TaxiDataSet();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.soferBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taxiDataSet2 = new Atestat_Taxi.TaxiDataSet();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taxiDataSet3 = new Atestat_Taxi.TaxiDataSet();
            this.ConfirmRegister = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.durataTextBox = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.masinaTableAdapter = new Atestat_Taxi.TaxiDataSetTableAdapters.MasinaTableAdapter();
            this.taxiDataSet1 = new Atestat_Taxi.TaxiDataSet();
            this.cursaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cursaTableAdapter = new Atestat_Taxi.TaxiDataSetTableAdapters.CursaTableAdapter();
            this.fKCursaMasinaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.soferTableAdapter = new Atestat_Taxi.TaxiDataSetTableAdapters.SoferTableAdapter();
            this.clientTableAdapter = new Atestat_Taxi.TaxiDataSetTableAdapters.ClientTableAdapter();
            label6 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            Id_masina_Label = new System.Windows.Forms.Label();
            durataLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.masinaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soferBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cursaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKCursaMasinaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(213, 103);
            label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(85, 13);
            label6.TabIndex = 70;
            label6.Text = "Lungime_traseu:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(213, 79);
            label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(29, 13);
            label5.TabIndex = 69;
            label5.Text = "Pret:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(213, 23);
            label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(86, 13);
            label4.TabIndex = 68;
            label4.Text = "Moment_plecare";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(8, 50);
            label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(32, 13);
            label3.TabIndex = 67;
            label3.Text = "Sofer";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(8, 78);
            label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(33, 13);
            label2.TabIndex = 66;
            label2.Text = "Client";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(213, 50);
            label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(78, 13);
            label1.TabIndex = 65;
            label1.Text = "Moment_sosire";
            // 
            // Id_masina_Label
            // 
            Id_masina_Label.AutoSize = true;
            Id_masina_Label.Location = new System.Drawing.Point(8, 26);
            Id_masina_Label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            Id_masina_Label.Name = "Id_masina_Label";
            Id_masina_Label.Size = new System.Drawing.Size(41, 13);
            Id_masina_Label.TabIndex = 62;
            Id_masina_Label.Text = "Masina";
            // 
            // durataLabel
            // 
            durataLabel.AutoSize = true;
            durataLabel.Location = new System.Drawing.Point(11, 107);
            durataLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            durataLabel.Name = "durataLabel";
            durataLabel.Size = new System.Drawing.Size(42, 13);
            durataLabel.TabIndex = 63;
            durataLabel.Text = "Durata:";
            // 
            // comboBox4
            // 
            this.comboBox4.DataSource = this.masinaBindingSource;
            this.comboBox4.DisplayMember = "Denumire";
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(54, 26);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 80;
            // 
            // masinaBindingSource
            // 
            this.masinaBindingSource.DataMember = "Masina";
            this.masinaBindingSource.DataSource = this.taxiDataSet;
            // 
            // taxiDataSet
            // 
            this.taxiDataSet.DataSetName = "TaxiDataSet";
            this.taxiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.soferBindingSource;
            this.comboBox3.DisplayMember = "Nume";
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(54, 50);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 79;
            // 
            // soferBindingSource
            // 
            this.soferBindingSource.DataMember = "Sofer";
            this.soferBindingSource.DataSource = this.taxiDataSet2;
            // 
            // taxiDataSet2
            // 
            this.taxiDataSet2.DataSetName = "TaxiDataSet";
            this.taxiDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.clientBindingSource;
            this.comboBox2.DisplayMember = "Nume";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(54, 77);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 78;
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.taxiDataSet3;
            // 
            // taxiDataSet3
            // 
            this.taxiDataSet3.DataSetName = "TaxiDataSet";
            this.taxiDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ConfirmRegister
            // 
            this.ConfirmRegister.Location = new System.Drawing.Point(102, 143);
            this.ConfirmRegister.Margin = new System.Windows.Forms.Padding(2);
            this.ConfirmRegister.Name = "ConfirmRegister";
            this.ConfirmRegister.Size = new System.Drawing.Size(235, 29);
            this.ConfirmRegister.TabIndex = 73;
            this.ConfirmRegister.Text = "Inregistrare";
            this.ConfirmRegister.UseVisualStyleBackColor = true;
            this.ConfirmRegister.Click += new System.EventHandler(this.ConfirmRegister_Click);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(312, 107);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(71, 20);
            this.textBox5.TabIndex = 72;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(312, 79);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(71, 20);
            this.textBox1.TabIndex = 71;
            // 
            // durataTextBox
            // 
            this.durataTextBox.Location = new System.Drawing.Point(54, 107);
            this.durataTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.durataTextBox.Name = "durataTextBox";
            this.durataTextBox.Size = new System.Drawing.Size(55, 20);
            this.durataTextBox.TabIndex = 64;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(312, 18);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 81;
            this.dateTimePicker1.Value = new System.DateTime(2021, 5, 27, 0, 0, 0, 0);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(312, 47);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 82;
            this.dateTimePicker2.Value = new System.DateTime(2021, 5, 27, 0, 0, 0, 0);
            // 
            // masinaTableAdapter
            // 
            this.masinaTableAdapter.ClearBeforeFill = true;
            // 
            // taxiDataSet1
            // 
            this.taxiDataSet1.DataSetName = "TaxiDataSet";
            this.taxiDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cursaBindingSource
            // 
            this.cursaBindingSource.DataMember = "Cursa";
            this.cursaBindingSource.DataSource = this.taxiDataSet1;
            // 
            // cursaTableAdapter
            // 
            this.cursaTableAdapter.ClearBeforeFill = true;
            // 
            // fKCursaMasinaBindingSource
            // 
            this.fKCursaMasinaBindingSource.DataMember = "FK_Cursa_Masina";
            this.fKCursaMasinaBindingSource.DataSource = this.masinaBindingSource;
            // 
            // soferTableAdapter
            // 
            this.soferTableAdapter.ClearBeforeFill = true;
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // AdaugareCursa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Atestat_Taxi.Properties.Resources.map_route_10854;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(521, 505);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.ConfirmRegister);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(label6);
            this.Controls.Add(label5);
            this.Controls.Add(label4);
            this.Controls.Add(label3);
            this.Controls.Add(label2);
            this.Controls.Add(label1);
            this.Controls.Add(Id_masina_Label);
            this.Controls.Add(durataLabel);
            this.Controls.Add(this.durataTextBox);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdaugareCursa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdaugareCursa";
            this.Load += new System.EventHandler(this.AdaugareCursa_Load);
            ((System.ComponentModel.ISupportInitialize)(this.masinaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soferBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cursaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKCursaMasinaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button ConfirmRegister;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox durataTextBox;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private TaxiDataSet taxiDataSet;
        private System.Windows.Forms.BindingSource masinaBindingSource;
        private TaxiDataSetTableAdapters.MasinaTableAdapter masinaTableAdapter;
        private TaxiDataSet taxiDataSet1;
        private System.Windows.Forms.BindingSource cursaBindingSource;
        private TaxiDataSetTableAdapters.CursaTableAdapter cursaTableAdapter;
        private System.Windows.Forms.BindingSource fKCursaMasinaBindingSource;
        private TaxiDataSet taxiDataSet2;
        private System.Windows.Forms.BindingSource soferBindingSource;
        private TaxiDataSetTableAdapters.SoferTableAdapter soferTableAdapter;
        private TaxiDataSet taxiDataSet3;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private TaxiDataSetTableAdapters.ClientTableAdapter clientTableAdapter;
    }
}