﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Atestat_Taxi
{
    public partial class ModificareCursa : Form
    {
        SqlConnection connection;
        public ModificareCursa()
        {
            InitializeComponent();
        }

        private void ModificareCursa_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'taxiDataSet.Client' table. You can move, or remove it, as needed.
            this.clientTableAdapter.Fill(this.taxiDataSet.Client);
            // TODO: This line of code loads data into the 'taxiDataSet.Sofer' table. You can move, or remove it, as needed.
            this.soferTableAdapter.Fill(this.taxiDataSet.Sofer);
            // TODO: This line of code loads data into the 'taxiDataSet.Masina' table. You can move, or remove it, as needed.
            this.masinaTableAdapter.Fill(this.taxiDataSet.Masina);
            // TODO: This line of code loads data into the 'taxiDataSet.Cursa' table. You can move, or remove it, as needed.
            this.cursaTableAdapter.Fill(this.taxiDataSet.Cursa);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Sunteti sigur ca vreti sa salvati modificarile ?", "Atentie !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (r == DialogResult.Yes)
            {
                String updateQuery = "UPDATE Cursa SET ";
                updateQuery += "[Id_masina] = @Id_masina, [Id_sofer] = @Id_sofer, [Id_client] = @Id_client, [Durata] = @Durata, [Moment_plecare] = @Moment_plecare, [Moment_sosire] = @Moment_sosire,[Pret] = @Pret,[Lungime_traseu] = @Lungime_traseu, [Status] = @Status ";
                updateQuery += "WHERE id = @id";
                if (connection == null)
                    connection = new SqlConnection(Properties.Settings.Default.dbConn);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();

                int id = Convert.ToInt32(CursadataGridView.CurrentRow.Cells["Id"].Value);
                int i = Convert.ToInt32(((DataRowView)comboBox4.SelectedValue)["Id"]);
                int j = Convert.ToInt32(((DataRowView)comboBox3.SelectedValue)["Id"]);
                int k = Convert.ToInt32(((DataRowView)comboBox2.SelectedValue)["Id"]);
               
                SqlCommand cmd = new SqlCommand(updateQuery, connection);
                cmd.Parameters.AddWithValue("@Id_masina", i);
                cmd.Parameters.AddWithValue("@Id_sofer", j);
                cmd.Parameters.AddWithValue("@Id_client", k);
                cmd.Parameters.AddWithValue("@Durata", Convert.ToInt32(durataTextBox.Text));
                cmd.Parameters.AddWithValue("@Moment_plecare", dateTimePicker1.Value.ToString("MM/dd/yyyy"));
                cmd.Parameters.AddWithValue("@Moment_sosire", dateTimePicker2.Value.ToString("MM/dd/yyyy"));
                cmd.Parameters.AddWithValue("@Pret", Convert.ToInt32(textBox1.Text));
                cmd.Parameters.AddWithValue("@Lungime_traseu", Convert.ToInt32(textBox5.Text));
                cmd.Parameters.AddWithValue("@Status", 1);
                cmd.Parameters.AddWithValue("@id", id);
                int result = cmd.ExecuteNonQuery();
                if (result == 1)
                {
                    MessageBox.Show("Modificarea s-a realizat cu succes !", "Success !", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cursaTableAdapter.Fill(taxiDataSet.Cursa);
                }
                else
                    MessageBox.Show("Eroare la modificarea datelor !", "Eroare !", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}

