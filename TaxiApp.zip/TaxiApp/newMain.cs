﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atestat_Taxi
{
    public partial class newMain : Form
    {


        public newMain()
        {
            InitializeComponent();

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Adaugare frm = new Adaugare()
            { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frm.FormBorderStyle= FormBorderStyle.None;
            this.pContainer.Controls.Add(frm);
            frm.Show();

        }

        private void bttnModify_Click(object sender, EventArgs e)
        {
            Modidicare frm = new Modidicare()
            { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            this.pContainer.Controls.Add(frm);
            frm.Show();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            Stergere frm = new Stergere()
            { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            this.pContainer.Controls.Add(frm);
            frm.Show();
        }

        private void btnmoney_Click(object sender, EventArgs e)
        {
            Venit frm = new Venit()
            { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            this.pContainer.Controls.Add(frm);
            frm.Show();
        }

        private void btnkm_Click(object sender, EventArgs e)
        {
            KM1 frm = new KM1()
            { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            this.pContainer.Controls.Add(frm);
            frm.Show();
        }

        private void btncurse_Click(object sender, EventArgs e)
        {
            Curse frm = new Curse()
            { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            this.pContainer.Controls.Add(frm);
            frm.Show();

        }

        private void newMain_Load(object sender, EventArgs e)
        {

        }

        private void pContainer_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

       
