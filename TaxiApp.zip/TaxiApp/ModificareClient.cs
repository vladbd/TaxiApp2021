﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Atestat_Taxi
{
    public partial class ModificareClient : Form
    {
        SqlConnection connection;
        public ModificareClient()
        {
            InitializeComponent();
        }

        private void ModificareClient_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'taxiDataSet.Client' table. You can move, or remove it, as needed.
            this.clientTableAdapter.Fill(this.taxiDataSet.Client);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Sunteti sigur ca vreti sa salvati modificarile ?", "Atentie !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (r == DialogResult.Yes)
            {
                String updateQuery = "UPDATE Client SET ";
                updateQuery += "[Nume] = @Nume, [Prenume] = @Prenume, [Localitate] = @Localitate, [Adresa] = @Adresa, [Telefon] = @Telefon, [Email ] = @Email, [Status] = @Status ";
                updateQuery += "WHERE id = @id";

                int id = Convert.ToInt32(CleintdataGridView.CurrentRow.Cells["Id"].Value);

                if (connection == null)
                    connection = new SqlConnection(Properties.Settings.Default.dbConn);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                SqlCommand cmd = new SqlCommand(updateQuery, connection);
                cmd.Parameters.AddWithValue("@Nume", inputNume.Text);
                cmd.Parameters.AddWithValue("@Prenume", inputPrenume.Text);
                cmd.Parameters.AddWithValue("@Localitate", inputLoc.Text);
                cmd.Parameters.AddWithValue("@Adresa", InputAdresa.Text);
                cmd.Parameters.AddWithValue("@Telefon", ImputTelefon.Text);
                cmd.Parameters.AddWithValue("@Email", ImputEmail.Text);
                cmd.Parameters.AddWithValue("@Status", 1);
                cmd.Parameters.AddWithValue("@id", id);

                int result = cmd.ExecuteNonQuery();
                if (result == 1)
                {
                    MessageBox.Show("Modificarea s-a realizat cu succes !", "Success !", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clientTableAdapter.Fill(taxiDataSet.Client);
                }
                else
                    MessageBox.Show("Eroare la modificarea datelor !", "Eroare !", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
