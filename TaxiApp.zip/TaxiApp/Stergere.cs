﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atestat_Taxi
{
    public partial class Stergere : Form
    {
        public Stergere()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StergereClient frm = new StergereClient();
            frm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StergereSofer frm = new StergereSofer();
            frm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            StergereMasina frm = new StergereMasina();
            frm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            StergereCursa frm = new StergereCursa();
            frm.Show();
        }
    }
}
