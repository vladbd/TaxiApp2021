﻿
namespace Atestat_Taxi
{
    partial class newMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(newMain));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btncurse = new System.Windows.Forms.Button();
            this.btnkm = new System.Windows.Forms.Button();
            this.btnmoney = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.bttnModify = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panelTop = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pContainer = new System.Windows.Forms.Panel();
            this.panelMenu.SuspendLayout();
            this.panelLogo.SuspendLayout();
            this.panelTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(162)))), ((int)(((byte)(2)))));
            this.panelMenu.Controls.Add(this.btncurse);
            this.panelMenu.Controls.Add(this.btnkm);
            this.panelMenu.Controls.Add(this.btnmoney);
            this.panelMenu.Controls.Add(this.btndelete);
            this.panelMenu.Controls.Add(this.bttnModify);
            this.panelMenu.Controls.Add(this.btnAdd);
            this.panelMenu.Controls.Add(this.panelLogo);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(220, 528);
            this.panelMenu.TabIndex = 0;
            // 
            // btncurse
            // 
            this.btncurse.AutoSize = true;
            this.btncurse.Dock = System.Windows.Forms.DockStyle.Top;
            this.btncurse.FlatAppearance.BorderSize = 0;
            this.btncurse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncurse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncurse.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btncurse.Image = global::Atestat_Taxi.Properties.Resources.workbench_icon_154590;
            this.btncurse.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btncurse.Location = new System.Drawing.Point(0, 431);
            this.btncurse.Name = "btncurse";
            this.btncurse.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.btncurse.Size = new System.Drawing.Size(220, 76);
            this.btncurse.TabIndex = 7;
            this.btncurse.Text = "  Raport Curse";
            this.btncurse.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btncurse.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btncurse.UseVisualStyleBackColor = true;
            this.btncurse.Click += new System.EventHandler(this.btncurse_Click);
            // 
            // btnkm
            // 
            this.btnkm.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnkm.FlatAppearance.BorderSize = 0;
            this.btnkm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnkm.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnkm.Image = global::Atestat_Taxi.Properties.Resources.map_distance_icon_155154;
            this.btnkm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnkm.Location = new System.Drawing.Point(0, 363);
            this.btnkm.Name = "btnkm";
            this.btnkm.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.btnkm.Size = new System.Drawing.Size(220, 68);
            this.btnkm.TabIndex = 6;
            this.btnkm.Text = "  Kilometraj";
            this.btnkm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnkm.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnkm.UseVisualStyleBackColor = true;
            this.btnkm.Click += new System.EventHandler(this.btnkm_Click);
            // 
            // btnmoney
            // 
            this.btnmoney.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnmoney.FlatAppearance.BorderSize = 0;
            this.btnmoney.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmoney.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnmoney.Image = global::Atestat_Taxi.Properties.Resources.usd_crypto_cryptocurrency_cryptocurrencies_cash_money_bank_payment_95707;
            this.btnmoney.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnmoney.Location = new System.Drawing.Point(0, 291);
            this.btnmoney.Name = "btnmoney";
            this.btnmoney.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.btnmoney.Size = new System.Drawing.Size(220, 72);
            this.btnmoney.TabIndex = 5;
            this.btnmoney.Text = "  Venit";
            this.btnmoney.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnmoney.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnmoney.UseVisualStyleBackColor = true;
            this.btnmoney.Click += new System.EventHandler(this.btnmoney_Click);
            // 
            // btndelete
            // 
            this.btndelete.Dock = System.Windows.Forms.DockStyle.Top;
            this.btndelete.FlatAppearance.BorderSize = 0;
            this.btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btndelete.Image = global::Atestat_Taxi.Properties.Resources.document_delete_256_icon_icons_com_75995;
            this.btndelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndelete.Location = new System.Drawing.Point(0, 218);
            this.btndelete.Name = "btndelete";
            this.btndelete.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.btndelete.Size = new System.Drawing.Size(220, 73);
            this.btndelete.TabIndex = 4;
            this.btndelete.Text = "  Stergere";
            this.btndelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // bttnModify
            // 
            this.bttnModify.Dock = System.Windows.Forms.DockStyle.Top;
            this.bttnModify.FlatAppearance.BorderSize = 0;
            this.bttnModify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttnModify.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnModify.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttnModify.Image = global::Atestat_Taxi.Properties.Resources.pen_edit_modify_pencil_icon_181536;
            this.bttnModify.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttnModify.Location = new System.Drawing.Point(0, 151);
            this.bttnModify.Name = "bttnModify";
            this.bttnModify.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.bttnModify.Size = new System.Drawing.Size(220, 67);
            this.bttnModify.TabIndex = 3;
            this.bttnModify.Text = "  Modificare";
            this.bttnModify.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttnModify.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bttnModify.UseVisualStyleBackColor = true;
            this.bttnModify.Click += new System.EventHandler(this.bttnModify_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAdd.Image = global::Atestat_Taxi.Properties.Resources.document_add_256_icon_icons_com_75994__1_;
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(0, 80);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.btnAdd.Size = new System.Drawing.Size(220, 71);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "  Adaugare";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(93)))), ((int)(((byte)(57)))));
            this.panelLogo.Controls.Add(this.button1);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(220, 80);
            this.panelLogo.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Image = global::Atestat_Taxi.Properties.Resources.taxi_cab_transportation_automobile_car_vehicle_icon_128574;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(220, 76);
            this.button1.TabIndex = 8;
            this.button1.Text = "All in One Taxi App";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(162)))), ((int)(((byte)(2)))));
            this.panelTop.Controls.Add(this.label1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(220, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(757, 80);
            this.panelTop.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(156, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(385, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Management Firma Taxi";
            // 
            // pContainer
            // 
            this.pContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pContainer.Location = new System.Drawing.Point(220, 80);
            this.pContainer.Name = "pContainer";
            this.pContainer.Size = new System.Drawing.Size(757, 448);
            this.pContainer.TabIndex = 2;
            this.pContainer.Paint += new System.Windows.Forms.PaintEventHandler(this.pContainer_Paint);
            // 
            // newMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(977, 528);
            this.Controls.Add(this.pContainer);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "newMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "newMain";
            this.Load += new System.EventHandler(this.newMain_Load);
            this.panelMenu.ResumeLayout(false);
            this.panelMenu.PerformLayout();
            this.panelLogo.ResumeLayout(false);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Button btnkm;
        private System.Windows.Forms.Button btnmoney;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button bttnModify;
        private System.Windows.Forms.Button btncurse;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pContainer;
    }
}