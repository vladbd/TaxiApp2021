﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Atestat_Taxi
{
    public partial class ModificareSofer : Form
    {
        SqlConnection connection;
        public ModificareSofer()
        {
            InitializeComponent();
        }

        private void ModificareSofer_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'taxiDataSet.Sofer' table. You can move, or remove it, as needed.
            this.soferTableAdapter.Fill(this.taxiDataSet.Sofer);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Sunteti sigur ca vreti sa salvati modificarile ?", "Atentie !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (r == DialogResult.Yes)
            {
                String updateQuery = "UPDATE Sofer SET ";
                updateQuery += "[Nume] = @Nume, [Prenume] = @Prenume, [Cnp] = @Cnp, [Localitate] = @Localitate, [Adresa] = @Adresa, [Telefon] = @Telefon, [Email ] = @Email, [Data_angajarii ] = @Data_angajarii, [Numar_autorizatie ] = @Numar_autorizatie, [Status] = @Status ";
                updateQuery += "WHERE id = @id";

                int id = Convert.ToInt32(SoferDataGridView.CurrentRow.Cells["Id"].Value);

                if (connection == null)
                    connection = new SqlConnection(Properties.Settings.Default.dbConn);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                SqlCommand cmd = new SqlCommand(updateQuery, connection);
                cmd.Parameters.AddWithValue("@Nume", inputNume.Text);
                cmd.Parameters.AddWithValue("@Prenume", inputPrenume.Text);
                cmd.Parameters.AddWithValue("@Cnp", inputcnp.Text);
                cmd.Parameters.AddWithValue("@Localitate", inputLoc.Text);
                cmd.Parameters.AddWithValue("@Adresa", InputAdresa.Text);
                cmd.Parameters.AddWithValue("@Telefon", ImputTelefon.Text);
                cmd.Parameters.AddWithValue("@Email", ImputEmail.Text);
                cmd.Parameters.AddWithValue("@Data_angajarii", dateTimePicker1.Value.ToString("MM/dd/yyyy"));
                cmd.Parameters.AddWithValue("@Numar_autorizatie", ImputNraut.Text);
                cmd.Parameters.AddWithValue("@Status", 1);
                cmd.Parameters.AddWithValue("@id", id);

                int result = cmd.ExecuteNonQuery();
                if (result == 1)
                {
                    MessageBox.Show("Modificarea s-a realizat cu succes !", "Success !", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    soferTableAdapter.Fill(taxiDataSet.Sofer);
                }
                else
                    MessageBox.Show("Eroare la modificarea datelor !", "Eroare !", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
