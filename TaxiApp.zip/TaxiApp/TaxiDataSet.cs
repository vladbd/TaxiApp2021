﻿namespace Atestat_Taxi
{


    partial class TaxiDataSet
    {
    }
}

namespace Atestat_Taxi.TaxiDataSetTableAdapters {
    
    
    public partial class CursaTableAdapter {
    }
}
