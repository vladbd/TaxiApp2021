﻿
namespace Atestat_Taxi
{
    partial class ModificareMasina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModificareMasina));
            this.MasinadataGridView = new System.Windows.Forms.DataGridView();
            this.masinaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taxiDataSet = new Atestat_Taxi.TaxiDataSet();
            this.masinaTableAdapter = new Atestat_Taxi.TaxiDataSetTableAdapters.MasinaTableAdapter();
            this.numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.InputDen = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.inputNrinm = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.inputInd = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.inputNume = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idtipmasinaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.indicativDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.denumireDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nrinmatriculareDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datainregistrariiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idtipcombustibilDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.MasinadataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masinaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // MasinadataGridView
            // 
            this.MasinadataGridView.AutoGenerateColumns = false;
            this.MasinadataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MasinadataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.idtipmasinaDataGridViewTextBoxColumn,
            this.indicativDataGridViewTextBoxColumn,
            this.denumireDataGridViewTextBoxColumn,
            this.nrinmatriculareDataGridViewTextBoxColumn,
            this.datainregistrariiDataGridViewTextBoxColumn,
            this.idtipcombustibilDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.MasinadataGridView.DataSource = this.masinaBindingSource;
            this.MasinadataGridView.Location = new System.Drawing.Point(12, 0);
            this.MasinadataGridView.Name = "MasinadataGridView";
            this.MasinadataGridView.Size = new System.Drawing.Size(547, 150);
            this.MasinadataGridView.TabIndex = 0;
            // 
            // masinaBindingSource
            // 
            this.masinaBindingSource.DataMember = "Masina";
            this.masinaBindingSource.DataSource = this.taxiDataSet;
            // 
            // taxiDataSet
            // 
            this.taxiDataSet.DataSetName = "TaxiDataSet";
            this.taxiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // masinaTableAdapter
            // 
            this.masinaTableAdapter.ClearBeforeFill = true;
            // 
            // numericUpDown
            // 
            this.numericUpDown.Location = new System.Drawing.Point(299, 252);
            this.numericUpDown.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numericUpDown.Name = "numericUpDown";
            this.numericUpDown.Size = new System.Drawing.Size(51, 20);
            this.numericUpDown.TabIndex = 71;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(296, 236);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 70;
            this.label3.Text = "Tip combustibil";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(294, 180);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(244, 20);
            this.dateTimePicker1.TabIndex = 69;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 325);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 13);
            this.label5.TabIndex = 68;
            this.label5.Text = "Numar Inmatriculare";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(296, 164);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 13);
            this.label10.TabIndex = 61;
            this.label10.Text = "Data Inregistrare";
            // 
            // InputDen
            // 
            this.InputDen.Location = new System.Drawing.Point(14, 291);
            this.InputDen.Margin = new System.Windows.Forms.Padding(2);
            this.InputDen.Name = "InputDen";
            this.InputDen.Size = new System.Drawing.Size(244, 20);
            this.InputDen.TabIndex = 67;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 276);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 66;
            this.label4.Text = "Denumire";
            // 
            // inputNrinm
            // 
            this.inputNrinm.Location = new System.Drawing.Point(14, 340);
            this.inputNrinm.Margin = new System.Windows.Forms.Padding(2);
            this.inputNrinm.Name = "inputNrinm";
            this.inputNrinm.Size = new System.Drawing.Size(244, 20);
            this.inputNrinm.TabIndex = 65;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 221);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 64;
            this.label2.Text = "Indicativ";
            // 
            // inputInd
            // 
            this.inputInd.Location = new System.Drawing.Point(14, 236);
            this.inputInd.Margin = new System.Windows.Forms.Padding(2);
            this.inputInd.Name = "inputInd";
            this.inputInd.Size = new System.Drawing.Size(244, 20);
            this.inputInd.TabIndex = 63;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 164);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 62;
            this.label1.Text = "Tip Masina";
            // 
            // inputNume
            // 
            this.inputNume.Location = new System.Drawing.Point(14, 179);
            this.inputNume.Margin = new System.Windows.Forms.Padding(2);
            this.inputNume.Name = "inputNume";
            this.inputNume.Size = new System.Drawing.Size(244, 20);
            this.inputNume.TabIndex = 60;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(299, 332);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(171, 28);
            this.button1.TabIndex = 72;
            this.button1.Text = "Modifica inregistrarea selectata";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // id
            // 
            this.id.DataPropertyName = "Id";
            this.id.HeaderText = "Id";
            this.id.Name = "id";
            this.id.Visible = false;
            // 
            // idtipmasinaDataGridViewTextBoxColumn
            // 
            this.idtipmasinaDataGridViewTextBoxColumn.DataPropertyName = "Id_tip_masina ";
            this.idtipmasinaDataGridViewTextBoxColumn.HeaderText = "Id_tip_masina ";
            this.idtipmasinaDataGridViewTextBoxColumn.Name = "idtipmasinaDataGridViewTextBoxColumn";
            this.idtipmasinaDataGridViewTextBoxColumn.Visible = false;
            // 
            // indicativDataGridViewTextBoxColumn
            // 
            this.indicativDataGridViewTextBoxColumn.DataPropertyName = "Indicativ";
            this.indicativDataGridViewTextBoxColumn.HeaderText = "Indicativ";
            this.indicativDataGridViewTextBoxColumn.Name = "indicativDataGridViewTextBoxColumn";
            // 
            // denumireDataGridViewTextBoxColumn
            // 
            this.denumireDataGridViewTextBoxColumn.DataPropertyName = "Denumire";
            this.denumireDataGridViewTextBoxColumn.HeaderText = "Denumire";
            this.denumireDataGridViewTextBoxColumn.Name = "denumireDataGridViewTextBoxColumn";
            // 
            // nrinmatriculareDataGridViewTextBoxColumn
            // 
            this.nrinmatriculareDataGridViewTextBoxColumn.DataPropertyName = "Nr_inmatriculare";
            this.nrinmatriculareDataGridViewTextBoxColumn.HeaderText = "Nr_inmatriculare";
            this.nrinmatriculareDataGridViewTextBoxColumn.Name = "nrinmatriculareDataGridViewTextBoxColumn";
            // 
            // datainregistrariiDataGridViewTextBoxColumn
            // 
            this.datainregistrariiDataGridViewTextBoxColumn.DataPropertyName = "Data_inregistrarii";
            this.datainregistrariiDataGridViewTextBoxColumn.HeaderText = "Data_inregistrarii";
            this.datainregistrariiDataGridViewTextBoxColumn.Name = "datainregistrariiDataGridViewTextBoxColumn";
            // 
            // idtipcombustibilDataGridViewTextBoxColumn
            // 
            this.idtipcombustibilDataGridViewTextBoxColumn.DataPropertyName = "Id_tip_combustibil";
            this.idtipcombustibilDataGridViewTextBoxColumn.HeaderText = "Id_tip_combustibil";
            this.idtipcombustibilDataGridViewTextBoxColumn.Name = "idtipcombustibilDataGridViewTextBoxColumn";
            this.idtipcombustibilDataGridViewTextBoxColumn.Visible = false;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            // 
            // ModificareMasina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(559, 372);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.numericUpDown);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.InputDen);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.inputNrinm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.inputInd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.inputNume);
            this.Controls.Add(this.MasinadataGridView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ModificareMasina";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ModificareMasina";
            this.Load += new System.EventHandler(this.ModificareMasina_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MasinadataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masinaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView MasinadataGridView;
        private TaxiDataSet taxiDataSet;
        private System.Windows.Forms.BindingSource masinaBindingSource;
        private TaxiDataSetTableAdapters.MasinaTableAdapter masinaTableAdapter;
        private System.Windows.Forms.NumericUpDown numericUpDown;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox InputDen;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox inputNrinm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox inputInd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox inputNume;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn idtipmasinaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn indicativDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn denumireDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nrinmatriculareDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datainregistrariiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idtipcombustibilDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
    }
}