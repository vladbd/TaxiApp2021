﻿
namespace Atestat_Taxi
{
    partial class ModificareSofer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModificareSofer));
            this.SoferDataGridView = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prenumeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cnpDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.localitateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataangajariiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numarautorizatieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soferBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taxiDataSet = new Atestat_Taxi.TaxiDataSet();
            this.soferTableAdapter = new Atestat_Taxi.TaxiDataSetTableAdapters.SoferTableAdapter();
            this.label2 = new System.Windows.Forms.Label();
            this.inputPrenume = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.inputNume = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.inputLoc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.inputcnp = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.InputAdresa = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ImputEmail = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ImputTelefon = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.ImputNraut = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.SoferDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soferBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // SoferDataGridView
            // 
            this.SoferDataGridView.AutoGenerateColumns = false;
            this.SoferDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SoferDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.numeDataGridViewTextBoxColumn,
            this.prenumeDataGridViewTextBoxColumn,
            this.cnpDataGridViewTextBoxColumn,
            this.localitateDataGridViewTextBoxColumn,
            this.adresaDataGridViewTextBoxColumn,
            this.telefonDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.dataangajariiDataGridViewTextBoxColumn,
            this.numarautorizatieDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.SoferDataGridView.DataSource = this.soferBindingSource;
            this.SoferDataGridView.Location = new System.Drawing.Point(12, 12);
            this.SoferDataGridView.Name = "SoferDataGridView";
            this.SoferDataGridView.Size = new System.Drawing.Size(1044, 237);
            this.SoferDataGridView.TabIndex = 0;
            // 
            // Id
            // 
            this.Id.DataPropertyName = "Id";
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.Visible = false;
            // 
            // numeDataGridViewTextBoxColumn
            // 
            this.numeDataGridViewTextBoxColumn.DataPropertyName = "Nume";
            this.numeDataGridViewTextBoxColumn.HeaderText = "Nume";
            this.numeDataGridViewTextBoxColumn.Name = "numeDataGridViewTextBoxColumn";
            // 
            // prenumeDataGridViewTextBoxColumn
            // 
            this.prenumeDataGridViewTextBoxColumn.DataPropertyName = "Prenume";
            this.prenumeDataGridViewTextBoxColumn.HeaderText = "Prenume";
            this.prenumeDataGridViewTextBoxColumn.Name = "prenumeDataGridViewTextBoxColumn";
            // 
            // cnpDataGridViewTextBoxColumn
            // 
            this.cnpDataGridViewTextBoxColumn.DataPropertyName = "Cnp";
            this.cnpDataGridViewTextBoxColumn.HeaderText = "Cnp";
            this.cnpDataGridViewTextBoxColumn.Name = "cnpDataGridViewTextBoxColumn";
            // 
            // localitateDataGridViewTextBoxColumn
            // 
            this.localitateDataGridViewTextBoxColumn.DataPropertyName = "Localitate";
            this.localitateDataGridViewTextBoxColumn.HeaderText = "Localitate";
            this.localitateDataGridViewTextBoxColumn.Name = "localitateDataGridViewTextBoxColumn";
            // 
            // adresaDataGridViewTextBoxColumn
            // 
            this.adresaDataGridViewTextBoxColumn.DataPropertyName = "Adresa";
            this.adresaDataGridViewTextBoxColumn.HeaderText = "Adresa";
            this.adresaDataGridViewTextBoxColumn.Name = "adresaDataGridViewTextBoxColumn";
            // 
            // telefonDataGridViewTextBoxColumn
            // 
            this.telefonDataGridViewTextBoxColumn.DataPropertyName = "Telefon";
            this.telefonDataGridViewTextBoxColumn.HeaderText = "Telefon";
            this.telefonDataGridViewTextBoxColumn.Name = "telefonDataGridViewTextBoxColumn";
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email ";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email ";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            // 
            // dataangajariiDataGridViewTextBoxColumn
            // 
            this.dataangajariiDataGridViewTextBoxColumn.DataPropertyName = "Data_angajarii ";
            this.dataangajariiDataGridViewTextBoxColumn.HeaderText = "Data_angajarii ";
            this.dataangajariiDataGridViewTextBoxColumn.Name = "dataangajariiDataGridViewTextBoxColumn";
            // 
            // numarautorizatieDataGridViewTextBoxColumn
            // 
            this.numarautorizatieDataGridViewTextBoxColumn.DataPropertyName = "Numar_autorizatie ";
            this.numarautorizatieDataGridViewTextBoxColumn.HeaderText = "Numar_autorizatie ";
            this.numarautorizatieDataGridViewTextBoxColumn.Name = "numarautorizatieDataGridViewTextBoxColumn";
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            // 
            // soferBindingSource
            // 
            this.soferBindingSource.DataMember = "Sofer";
            this.soferBindingSource.DataSource = this.taxiDataSet;
            // 
            // taxiDataSet
            // 
            this.taxiDataSet.DataSetName = "TaxiDataSet";
            this.taxiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // soferTableAdapter
            // 
            this.soferTableAdapter.ClearBeforeFill = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 296);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Prenume";
            // 
            // inputPrenume
            // 
            this.inputPrenume.Location = new System.Drawing.Point(11, 316);
            this.inputPrenume.Margin = new System.Windows.Forms.Padding(2);
            this.inputPrenume.Name = "inputPrenume";
            this.inputPrenume.Size = new System.Drawing.Size(231, 20);
            this.inputPrenume.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 252);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Nume";
            // 
            // inputNume
            // 
            this.inputNume.Location = new System.Drawing.Point(14, 271);
            this.inputNume.Margin = new System.Windows.Forms.Padding(2);
            this.inputNume.Name = "inputNume";
            this.inputNume.Size = new System.Drawing.Size(231, 20);
            this.inputNume.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 404);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "Localitate";
            // 
            // inputLoc
            // 
            this.inputLoc.Location = new System.Drawing.Point(11, 419);
            this.inputLoc.Margin = new System.Windows.Forms.Padding(2);
            this.inputLoc.Name = "inputLoc";
            this.inputLoc.Size = new System.Drawing.Size(231, 20);
            this.inputLoc.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 345);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Cod Numeric Personal";
            // 
            // inputcnp
            // 
            this.inputcnp.Location = new System.Drawing.Point(11, 365);
            this.inputcnp.Margin = new System.Windows.Forms.Padding(2);
            this.inputcnp.Name = "inputcnp";
            this.inputcnp.Size = new System.Drawing.Size(231, 20);
            this.inputcnp.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(282, 252);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "Adresa";
            // 
            // InputAdresa
            // 
            this.InputAdresa.Location = new System.Drawing.Point(282, 270);
            this.InputAdresa.Margin = new System.Windows.Forms.Padding(2);
            this.InputAdresa.Name = "InputAdresa";
            this.InputAdresa.Size = new System.Drawing.Size(231, 20);
            this.InputAdresa.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(276, 345);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 13);
            this.label9.TabIndex = 27;
            this.label9.Text = "Email";
            // 
            // ImputEmail
            // 
            this.ImputEmail.Location = new System.Drawing.Point(279, 365);
            this.ImputEmail.Margin = new System.Windows.Forms.Padding(2);
            this.ImputEmail.Name = "ImputEmail";
            this.ImputEmail.Size = new System.Drawing.Size(231, 20);
            this.ImputEmail.TabIndex = 26;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(279, 296);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "Numar telefon";
            // 
            // ImputTelefon
            // 
            this.ImputTelefon.Location = new System.Drawing.Point(282, 316);
            this.ImputTelefon.Margin = new System.Windows.Forms.Padding(2);
            this.ImputTelefon.Name = "ImputTelefon";
            this.ImputTelefon.Size = new System.Drawing.Size(231, 20);
            this.ImputTelefon.TabIndex = 24;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(276, 420);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(231, 20);
            this.dateTimePicker1.TabIndex = 31;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(554, 252);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 13);
            this.label7.TabIndex = 30;
            this.label7.Text = "Numar Autorizatie";
            // 
            // ImputNraut
            // 
            this.ImputNraut.Location = new System.Drawing.Point(554, 271);
            this.ImputNraut.Margin = new System.Windows.Forms.Padding(2);
            this.ImputNraut.Name = "ImputNraut";
            this.ImputNraut.Size = new System.Drawing.Size(231, 20);
            this.ImputNraut.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(276, 404);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 13);
            this.label8.TabIndex = 28;
            this.label8.Text = "Data Angajarii";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(874, 419);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(171, 28);
            this.button1.TabIndex = 32;
            this.button1.Text = "Modifica inregistrarea selectata";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ModificareSofer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1056, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.ImputNraut);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.ImputEmail);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.ImputTelefon);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.InputAdresa);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.inputLoc);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.inputcnp);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.inputPrenume);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.inputNume);
            this.Controls.Add(this.SoferDataGridView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ModificareSofer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ModificareSofer";
            this.Load += new System.EventHandler(this.ModificareSofer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SoferDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soferBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView SoferDataGridView;
        private TaxiDataSet taxiDataSet;
        private System.Windows.Forms.BindingSource soferBindingSource;
        private TaxiDataSetTableAdapters.SoferTableAdapter soferTableAdapter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox inputPrenume;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox inputNume;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox inputLoc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox inputcnp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox InputAdresa;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox ImputEmail;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox ImputTelefon;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox ImputNraut;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prenumeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cnpDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn localitateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataangajariiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numarautorizatieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
    }
}