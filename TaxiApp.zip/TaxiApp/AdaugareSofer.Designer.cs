﻿
namespace Atestat_Taxi
{
    partial class AdaugareSofer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdaugareSofer));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.ImputNraut = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.ImputEmail = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ImputTelefon = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.InputAdresa = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.inputLoc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.inputcnp = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.inputPrenume = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.inputNume = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dateTimePicker1);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.ImputNraut);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.ImputEmail);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.ImputTelefon);
            this.groupBox2.Location = new System.Drawing.Point(409, 28);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(277, 309);
            this.groupBox2.TabIndex = 25;
            this.groupBox2.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(23, 152);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(231, 20);
            this.dateTimePicker1.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 186);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Numar Autorizatie";
            // 
            // ImputNraut
            // 
            this.ImputNraut.Location = new System.Drawing.Point(23, 205);
            this.ImputNraut.Margin = new System.Windows.Forms.Padding(2);
            this.ImputNraut.Name = "ImputNraut";
            this.ImputNraut.Size = new System.Drawing.Size(231, 20);
            this.ImputNraut.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 136);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Data Angajarii";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(23, 81);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Email";
            // 
            // ImputEmail
            // 
            this.ImputEmail.Location = new System.Drawing.Point(23, 100);
            this.ImputEmail.Margin = new System.Windows.Forms.Padding(2);
            this.ImputEmail.Name = "ImputEmail";
            this.ImputEmail.Size = new System.Drawing.Size(231, 20);
            this.ImputEmail.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(23, 28);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "Numar telefon";
            // 
            // ImputTelefon
            // 
            this.ImputTelefon.Location = new System.Drawing.Point(23, 43);
            this.ImputTelefon.Margin = new System.Windows.Forms.Padding(2);
            this.ImputTelefon.Name = "ImputTelefon";
            this.ImputTelefon.Size = new System.Drawing.Size(231, 20);
            this.ImputTelefon.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(292, 329);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 29);
            this.button1.TabIndex = 24;
            this.button1.Text = "Inregistrare";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.InputAdresa);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.inputLoc);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.inputcnp);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.inputPrenume);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.inputNume);
            this.groupBox1.Location = new System.Drawing.Point(11, 28);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(277, 309);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 236);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Adresa";
            // 
            // InputAdresa
            // 
            this.InputAdresa.Location = new System.Drawing.Point(23, 254);
            this.InputAdresa.Margin = new System.Windows.Forms.Padding(2);
            this.InputAdresa.Name = "InputAdresa";
            this.InputAdresa.Size = new System.Drawing.Size(231, 20);
            this.InputAdresa.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 186);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Localitate";
            // 
            // inputLoc
            // 
            this.inputLoc.Location = new System.Drawing.Point(23, 205);
            this.inputLoc.Margin = new System.Windows.Forms.Padding(2);
            this.inputLoc.Name = "inputLoc";
            this.inputLoc.Size = new System.Drawing.Size(231, 20);
            this.inputLoc.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 136);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Cod Numeric Personal";
            // 
            // inputcnp
            // 
            this.inputcnp.Location = new System.Drawing.Point(23, 151);
            this.inputcnp.Margin = new System.Windows.Forms.Padding(2);
            this.inputcnp.Name = "inputcnp";
            this.inputcnp.Size = new System.Drawing.Size(231, 20);
            this.inputcnp.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 81);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Prenume";
            // 
            // inputPrenume
            // 
            this.inputPrenume.Location = new System.Drawing.Point(23, 100);
            this.inputPrenume.Margin = new System.Windows.Forms.Padding(2);
            this.inputPrenume.Name = "inputPrenume";
            this.inputPrenume.Size = new System.Drawing.Size(231, 20);
            this.inputPrenume.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 24);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Nume";
            // 
            // inputNume
            // 
            this.inputNume.Location = new System.Drawing.Point(26, 43);
            this.inputNume.Margin = new System.Windows.Forms.Padding(2);
            this.inputNume.Name = "inputNume";
            this.inputNume.Size = new System.Drawing.Size(231, 20);
            this.inputNume.TabIndex = 10;
            // 
            // AdaugareSofer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Atestat_Taxi.Properties.Resources.business_application_addmale_useradd_insert_add_user_client_2312;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(697, 369);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdaugareSofer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdaugareSofer";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox ImputNraut;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox ImputEmail;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox ImputTelefon;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox InputAdresa;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox inputLoc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox inputcnp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox inputPrenume;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox inputNume;
    }
}