﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Atestat_Taxi
{
    public partial class Km : Form
    {
        SqlConnection connection;
        public Km()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string i = comboBox1.SelectedValue.ToString();
            //MessageBox.Show(i);

            if (connection == null)
                connection = new SqlConnection(Properties.Settings.Default.dbConn);
            if (connection.State == ConnectionState.Closed)
                connection.Open();
            String updateQuery = "SELECT SUM(Lungime_traseu) FROM Cursa WHERE Id_sofer=@id_sofer";
            SqlCommand cmd = new SqlCommand(updateQuery, connection);
            cmd.Parameters.AddWithValue("@id_sofer", i);
            object result = cmd.ExecuteScalar();
            textBox1.Text = result.ToString();

        }

        private void Km_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'taxiDataSet.Sofer' table. You can move, or remove it, as needed.
            this.soferTableAdapter.Fill(this.taxiDataSet.Sofer);

        }
        
    }
}
