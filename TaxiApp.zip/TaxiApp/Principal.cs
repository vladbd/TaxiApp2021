﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atestat_Taxi
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }


        private void Principal_Load(object sender, EventArgs e)
        {

        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(-1, 147);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 29);
            this.button1.TabIndex = 0;
            this.button1.Text = "Adauga Sofer";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(-1, 182);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(143, 29);
            this.button2.TabIndex = 1;
            this.button2.Text = "Adauga Client";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(-1, 217);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(143, 29);
            this.button3.TabIndex = 2;
            this.button3.Text = "Adauga Masina";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(-1, 252);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(143, 29);
            this.button4.TabIndex = 3;
            this.button4.Text = "Adauga Cursa";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button5.Location = new System.Drawing.Point(-1, 287);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(143, 23);
            this.button5.TabIndex = 4;
            this.button5.Text = "Modifica Sofer";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button6.Location = new System.Drawing.Point(-1, 374);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(143, 23);
            this.button6.TabIndex = 5;
            this.button6.Text = "Modifica Cursa";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button7.Location = new System.Drawing.Point(-1, 345);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(143, 23);
            this.button7.TabIndex = 6;
            this.button7.Text = "Modifica Masina";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Image = ((System.Drawing.Image)(resources.GetObject("button8.Image")));
            this.button8.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button8.Location = new System.Drawing.Point(-1, 316);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(143, 23);
            this.button8.TabIndex = 7;
            this.button8.Text = "Modifica Client";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Image = ((System.Drawing.Image)(resources.GetObject("button9.Image")));
            this.button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.Location = new System.Drawing.Point(655, 123);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(139, 39);
            this.button9.TabIndex = 8;
            this.button9.Text = "Sterge Sofer";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Image = ((System.Drawing.Image)(resources.GetObject("button10.Image")));
            this.button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.Location = new System.Drawing.Point(655, 168);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(139, 39);
            this.button10.TabIndex = 9;
            this.button10.Text = "Sterge Client";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Image = ((System.Drawing.Image)(resources.GetObject("button11.Image")));
            this.button11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button11.Location = new System.Drawing.Point(655, 213);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(139, 39);
            this.button11.TabIndex = 10;
            this.button11.Text = "Sterge Masina";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Image = ((System.Drawing.Image)(resources.GetObject("button12.Image")));
            this.button12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button12.Location = new System.Drawing.Point(655, 258);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(139, 39);
            this.button12.TabIndex = 11;
            this.button12.Text = "Sterge Cursa";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Image = ((System.Drawing.Image)(resources.GetObject("button13.Image")));
            this.button13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button13.Location = new System.Drawing.Point(611, 374);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(183, 42);
            this.button13.TabIndex = 12;
            this.button13.Text = "Generare Venit/ Sofer";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.Image = ((System.Drawing.Image)(resources.GetObject("button14.Image")));
            this.button14.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button14.Location = new System.Drawing.Point(611, 422);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(181, 42);
            this.button14.TabIndex = 13;
            this.button14.Text = "Total Km/ Sofer";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Image = global::Atestat_Taxi.Properties.Resources.calendar_clock_schedule_icon_icons_com_51085;
            this.button15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button15.Location = new System.Drawing.Point(611, 470);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(183, 42);
            this.button15.TabIndex = 14;
            this.button15.Text = "Total Curse/ Sofer";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // Principal
            // 
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(795, 517);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ecran Principal";
            this.ResumeLayout(false);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdaugareSofer frm = new AdaugareSofer();
            frm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdaugaClient frm = new AdaugaClient();
            frm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdaugareMasina frm = new AdaugareMasina();
            frm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AdaugareCursa frm = new AdaugareCursa();
            frm.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ModificareSofer frm = new ModificareSofer();
            frm.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ModificareClient frm = new ModificareClient();
            frm.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ModificareMasina frm = new ModificareMasina();
            frm.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ModificareCursa frm = new ModificareCursa();
            frm.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            StergereSofer frm = new StergereSofer();
            frm.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            StergereMasina frm = new StergereMasina();
            frm.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            StergereCursa frm = new StergereCursa();
            frm.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Venit frm = new Venit();
            frm.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            KM1 frm = new KM1();
            frm.Show();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Curse frm = new Curse();
            frm.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            StergereClient frm = new StergereClient();
            frm.Show();
        }
    }
}
