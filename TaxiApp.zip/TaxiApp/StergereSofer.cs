﻿using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Atestat_Taxi
{
    public partial class StergereSofer : Form
    {
        SqlConnection connection;
        public StergereSofer()
        {
            InitializeComponent();
        }

        private void StergereSofer_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'taxiDataSet.Sofer' table. You can move, or remove it, as needed.
            this.soferTableAdapter.Fill(this.taxiDataSet.Sofer);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult response = MessageBox.Show("Sunteti sigur ?", "Atentie !", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (response == DialogResult.Yes)
            {
                int id = Convert.ToInt32(SoferdataGridView.CurrentRow.Cells["Id"].Value);
                String updateQuery = "UPDATE Sofer SET [status] = 2 ";
                updateQuery += "WHERE id = @id";
                if (connection == null)
                    connection = new SqlConnection(Properties.Settings.Default.dbConn);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                SqlCommand cmd = new SqlCommand(updateQuery, connection);
                cmd.Parameters.AddWithValue("@id", id);
                int result = cmd.ExecuteNonQuery();
                if (result == 1)
                {
                    MessageBox.Show("Stergerea s-a realizat cu succes !", "Success !", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    soferTableAdapter.Fill(taxiDataSet.Sofer);
                }
                else
                    MessageBox.Show("Eroare la stergerea datelor !", "Eroare !", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
