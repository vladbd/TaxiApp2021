﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Atestat_Taxi
{
    public partial class AdaugaClient : Form
    {
        SqlConnection conn;
        public AdaugaClient()
        {
            InitializeComponent();
        }

        private void ConfirmRegister_Click(object sender, EventArgs e)
        {
            String insertSql = "INSERT INTO Client (Nume, Prenume, Localitate, Adresa, Telefon, Email, Status) VALUES ('";
            insertSql += inputNume.Text + "', '" + inputPrenume.Text + "', '"  + inputLoc.Text + "', '" + InputAdresa.Text + "', '" + ImputTelefon.Text + "', '" + ImputEmail.Text + "' , 1)";

            //MessageBox.Show(insertSql);

            if (conn == null)
                conn = new SqlConnection(Properties.Settings.Default.dbConn);
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            SqlCommand cmd = new SqlCommand(insertSql, conn);
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
                MessageBox.Show("Adaugare cu succes !", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Eroare la adaugarea in tabela !", "Atentie !", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
