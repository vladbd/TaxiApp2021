﻿
namespace Atestat_Taxi
{
    partial class StergereCursa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CursadataGridView = new System.Windows.Forms.DataGridView();
            this.cursaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taxiDataSet = new Atestat_Taxi.TaxiDataSet();
            this.cursaTableAdapter = new Atestat_Taxi.TaxiDataSetTableAdapters.CursaTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idmasinaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idsoferDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idclientDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.durataDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.momentplecareDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.momentsosireDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pretDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lungimetraseuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.CursadataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cursaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // CursadataGridView
            // 
            this.CursadataGridView.AutoGenerateColumns = false;
            this.CursadataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CursadataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.idmasinaDataGridViewTextBoxColumn,
            this.idsoferDataGridViewTextBoxColumn,
            this.idclientDataGridViewTextBoxColumn,
            this.durataDataGridViewTextBoxColumn,
            this.momentplecareDataGridViewTextBoxColumn,
            this.momentsosireDataGridViewTextBoxColumn,
            this.pretDataGridViewTextBoxColumn,
            this.lungimetraseuDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.CursadataGridView.DataSource = this.cursaBindingSource;
            this.CursadataGridView.Location = new System.Drawing.Point(1, 3);
            this.CursadataGridView.Name = "CursadataGridView";
            this.CursadataGridView.Size = new System.Drawing.Size(647, 142);
            this.CursadataGridView.TabIndex = 0;
            // 
            // cursaBindingSource
            // 
            this.cursaBindingSource.DataMember = "Cursa";
            this.cursaBindingSource.DataSource = this.taxiDataSet;
            // 
            // taxiDataSet
            // 
            this.taxiDataSet.DataSetName = "TaxiDataSet";
            this.taxiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cursaTableAdapter
            // 
            this.cursaTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(212, 155);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(273, 35);
            this.button1.TabIndex = 3;
            this.button1.Text = "Sterge linia selectata";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Id
            // 
            this.Id.DataPropertyName = "Id";
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.Visible = false;
            // 
            // idmasinaDataGridViewTextBoxColumn
            // 
            this.idmasinaDataGridViewTextBoxColumn.DataPropertyName = "Id_masina";
            this.idmasinaDataGridViewTextBoxColumn.HeaderText = "Id_masina";
            this.idmasinaDataGridViewTextBoxColumn.Name = "idmasinaDataGridViewTextBoxColumn";
            this.idmasinaDataGridViewTextBoxColumn.Visible = false;
            // 
            // idsoferDataGridViewTextBoxColumn
            // 
            this.idsoferDataGridViewTextBoxColumn.DataPropertyName = "Id_sofer";
            this.idsoferDataGridViewTextBoxColumn.HeaderText = "Id_sofer";
            this.idsoferDataGridViewTextBoxColumn.Name = "idsoferDataGridViewTextBoxColumn";
            this.idsoferDataGridViewTextBoxColumn.Visible = false;
            // 
            // idclientDataGridViewTextBoxColumn
            // 
            this.idclientDataGridViewTextBoxColumn.DataPropertyName = "Id_client";
            this.idclientDataGridViewTextBoxColumn.HeaderText = "Id_client";
            this.idclientDataGridViewTextBoxColumn.Name = "idclientDataGridViewTextBoxColumn";
            this.idclientDataGridViewTextBoxColumn.Visible = false;
            // 
            // durataDataGridViewTextBoxColumn
            // 
            this.durataDataGridViewTextBoxColumn.DataPropertyName = "Durata";
            this.durataDataGridViewTextBoxColumn.HeaderText = "Durata";
            this.durataDataGridViewTextBoxColumn.Name = "durataDataGridViewTextBoxColumn";
            // 
            // momentplecareDataGridViewTextBoxColumn
            // 
            this.momentplecareDataGridViewTextBoxColumn.DataPropertyName = "Moment_plecare";
            this.momentplecareDataGridViewTextBoxColumn.HeaderText = "Moment_plecare";
            this.momentplecareDataGridViewTextBoxColumn.Name = "momentplecareDataGridViewTextBoxColumn";
            // 
            // momentsosireDataGridViewTextBoxColumn
            // 
            this.momentsosireDataGridViewTextBoxColumn.DataPropertyName = "Moment_sosire";
            this.momentsosireDataGridViewTextBoxColumn.HeaderText = "Moment_sosire";
            this.momentsosireDataGridViewTextBoxColumn.Name = "momentsosireDataGridViewTextBoxColumn";
            // 
            // pretDataGridViewTextBoxColumn
            // 
            this.pretDataGridViewTextBoxColumn.DataPropertyName = "Pret";
            this.pretDataGridViewTextBoxColumn.HeaderText = "Pret";
            this.pretDataGridViewTextBoxColumn.Name = "pretDataGridViewTextBoxColumn";
            // 
            // lungimetraseuDataGridViewTextBoxColumn
            // 
            this.lungimetraseuDataGridViewTextBoxColumn.DataPropertyName = "Lungime_traseu";
            this.lungimetraseuDataGridViewTextBoxColumn.HeaderText = "Lungime_traseu";
            this.lungimetraseuDataGridViewTextBoxColumn.Name = "lungimetraseuDataGridViewTextBoxColumn";
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            // 
            // StergereCursa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 201);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.CursadataGridView);
            this.Name = "StergereCursa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StergereCursa";
            this.Load += new System.EventHandler(this.StergereCursa_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CursadataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cursaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView CursadataGridView;
        private TaxiDataSet taxiDataSet;
        private System.Windows.Forms.BindingSource cursaBindingSource;
        private TaxiDataSetTableAdapters.CursaTableAdapter cursaTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn idmasinaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idsoferDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idclientDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn durataDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn momentplecareDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn momentsosireDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pretDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lungimetraseuDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
    }
}