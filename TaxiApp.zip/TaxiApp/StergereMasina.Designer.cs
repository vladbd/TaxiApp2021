﻿
namespace Atestat_Taxi
{
    partial class StergereMasina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MasinadataGridView = new System.Windows.Forms.DataGridView();
            this.masinaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taxiDataSet = new Atestat_Taxi.TaxiDataSet();
            this.masinaTableAdapter = new Atestat_Taxi.TaxiDataSetTableAdapters.MasinaTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idtipmasinaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.indicativDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.denumireDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nrinmatriculareDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datainregistrariiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idtipcombustibilDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.MasinadataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masinaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // MasinadataGridView
            // 
            this.MasinadataGridView.AutoGenerateColumns = false;
            this.MasinadataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MasinadataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.idtipmasinaDataGridViewTextBoxColumn,
            this.indicativDataGridViewTextBoxColumn,
            this.denumireDataGridViewTextBoxColumn,
            this.nrinmatriculareDataGridViewTextBoxColumn,
            this.datainregistrariiDataGridViewTextBoxColumn,
            this.idtipcombustibilDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.MasinadataGridView.DataSource = this.masinaBindingSource;
            this.MasinadataGridView.Location = new System.Drawing.Point(2, 2);
            this.MasinadataGridView.Name = "MasinadataGridView";
            this.MasinadataGridView.Size = new System.Drawing.Size(548, 140);
            this.MasinadataGridView.TabIndex = 0;
            // 
            // masinaBindingSource
            // 
            this.masinaBindingSource.DataMember = "Masina";
            this.masinaBindingSource.DataSource = this.taxiDataSet;
            // 
            // taxiDataSet
            // 
            this.taxiDataSet.DataSetName = "TaxiDataSet";
            this.taxiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // masinaTableAdapter
            // 
            this.masinaTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(133, 165);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(273, 28);
            this.button1.TabIndex = 3;
            this.button1.Text = "Sterge linia selectata";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Id
            // 
            this.Id.DataPropertyName = "Id";
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.Visible = false;
            // 
            // idtipmasinaDataGridViewTextBoxColumn
            // 
            this.idtipmasinaDataGridViewTextBoxColumn.DataPropertyName = "Id_tip_masina ";
            this.idtipmasinaDataGridViewTextBoxColumn.HeaderText = "Id_tip_masina ";
            this.idtipmasinaDataGridViewTextBoxColumn.Name = "idtipmasinaDataGridViewTextBoxColumn";
            this.idtipmasinaDataGridViewTextBoxColumn.Visible = false;
            // 
            // indicativDataGridViewTextBoxColumn
            // 
            this.indicativDataGridViewTextBoxColumn.DataPropertyName = "Indicativ";
            this.indicativDataGridViewTextBoxColumn.HeaderText = "Indicativ";
            this.indicativDataGridViewTextBoxColumn.Name = "indicativDataGridViewTextBoxColumn";
            // 
            // denumireDataGridViewTextBoxColumn
            // 
            this.denumireDataGridViewTextBoxColumn.DataPropertyName = "Denumire";
            this.denumireDataGridViewTextBoxColumn.HeaderText = "Denumire";
            this.denumireDataGridViewTextBoxColumn.Name = "denumireDataGridViewTextBoxColumn";
            // 
            // nrinmatriculareDataGridViewTextBoxColumn
            // 
            this.nrinmatriculareDataGridViewTextBoxColumn.DataPropertyName = "Nr_inmatriculare";
            this.nrinmatriculareDataGridViewTextBoxColumn.HeaderText = "Nr_inmatriculare";
            this.nrinmatriculareDataGridViewTextBoxColumn.Name = "nrinmatriculareDataGridViewTextBoxColumn";
            // 
            // datainregistrariiDataGridViewTextBoxColumn
            // 
            this.datainregistrariiDataGridViewTextBoxColumn.DataPropertyName = "Data_inregistrarii";
            this.datainregistrariiDataGridViewTextBoxColumn.HeaderText = "Data_inregistrarii";
            this.datainregistrariiDataGridViewTextBoxColumn.Name = "datainregistrariiDataGridViewTextBoxColumn";
            // 
            // idtipcombustibilDataGridViewTextBoxColumn
            // 
            this.idtipcombustibilDataGridViewTextBoxColumn.DataPropertyName = "Id_tip_combustibil";
            this.idtipcombustibilDataGridViewTextBoxColumn.HeaderText = "Id_tip_combustibil";
            this.idtipcombustibilDataGridViewTextBoxColumn.Name = "idtipcombustibilDataGridViewTextBoxColumn";
            this.idtipcombustibilDataGridViewTextBoxColumn.Visible = false;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            // 
            // StergereMasina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(557, 219);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.MasinadataGridView);
            this.Name = "StergereMasina";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StergereMasina";
            this.Load += new System.EventHandler(this.StergereMasina_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MasinadataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masinaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taxiDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView MasinadataGridView;
        private TaxiDataSet taxiDataSet;
        private System.Windows.Forms.BindingSource masinaBindingSource;
        private TaxiDataSetTableAdapters.MasinaTableAdapter masinaTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn idtipmasinaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn indicativDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn denumireDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nrinmatriculareDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datainregistrariiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idtipcombustibilDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
    }
}